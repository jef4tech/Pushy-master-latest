<?php
require('dbConnect.php');
$x=$_GET['token'];
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO devices(token)VALUES ('".$x."')";

            if (mysqli_query($conn, $sql)) {
             
            } else {
               echo "Error: " . $sql . "" . mysqli_error($conn);
            }
            mysqli_close($conn);
?>