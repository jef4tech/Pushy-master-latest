<?php
// Require Pushy API Class
require('pushy.php');

// Payload data you want to send to devices
$data = array('message' => 'newer notific!');

// The recipient device tokens
/*$to = array('8e775da09879c4c38c5b8a');*/

// Optionally, send to a publish/subscribe topic instead
$to = '/topics/news';

// Optional push notification options (such as iOS notification fields)
$options = array(
    'notification' => array(
        'badge' => 1,
        'sound' => 'ping.aiff',
        'body'  => "Hello World \xE2\x9C\x8C"
    )
);

// Send it with Pushy
PushyAPI::sendPushNotification($data, $to, $options);
?>
